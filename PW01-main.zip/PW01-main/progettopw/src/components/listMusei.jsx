import { GetMusei } from "./crud/crudMuseo";
import Filter from "./filter";

const ListMusei = () => {
  return (
      <div>
        <GetMusei />
      </div>
  );
};

export { ListMusei };
