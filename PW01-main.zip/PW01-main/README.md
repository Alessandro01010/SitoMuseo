# PW01
### Lavoro progetto di gruppo - Facciani/Barzaghi/Ricci/Maggi

Il project work da realizzare consiste in un sito web che permette agli
utenti di poter visionare musei o eventi artistici vicino rispetto alla loro
attuale posizione.
Nello specifico il sistema deve produrre una sorta di guida per le mostre
e identificare una serie di eventi correlati rispetto a quanto effettuato in
precedenza dall’utente stesso.
Il sito in questione è da sviluppare tramite framework (si consiglia di usare
Firebase di Google come sistema serverless per la base di dati e backend)
